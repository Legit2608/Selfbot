Welcome to scalic.

Scalic is a discord selfbot with tons of features

Scalic is frequently updated and is designed to be a fun bot


# Commands
The default prefix is `!` , you can change this in the settings file!



## 🖥️ System Commands

Command | Aliases | Description | Arguments | Example
---|---|---|---|---
`help` | `commands`, `commandlist`, `commandslist`, `allcommands` , `h`| Show the commands for certain categories | Category to get help on | `!help`, `!help text`, `!help fun`
`download` | `scalicselfbot`, `scalic`, `link`, `website`| Sends the link to get scalic with, along with a fancy embed | None | `!download`
`ping` | `pong`, `latency`| Responds in milliseconds on the bots response time | None | `!ping`
`notifications` | `notificationson`, `notificationsoff`, `notifs`, `notis`, `noti`, `alerts`| When being pinged, you'll get a custom alert with the server, channel and message content | on/off | `!notifications on`
`logout` | `logoff`, `close`| Turns bot off - commands will stop working after this | None | `!logout`


Tons more commands but there's too many for me to do

Scalic was created by [kieronia](http://kieronia.com/).
